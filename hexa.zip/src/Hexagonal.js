import React from "react";

const Hexagonal = props => {
  return <div className="hexagon" />;
};

export default Hexagonal;
